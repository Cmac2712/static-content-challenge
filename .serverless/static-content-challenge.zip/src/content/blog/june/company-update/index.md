# June Company Update

Acme Co. continues to thrive across all its industry verticals and the outlook remains rosy for the rest of the financial year.

We welcome feedback from our customer base - get in touch with Customer Services at contact@acme.com for more information.
